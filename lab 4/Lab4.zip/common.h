typedef struct _test_struct{
    
    // OLD:
    // unsigned int a;
    // unsigned int b;

    char name[255];
    char age[255];
    char group[255];

} test_struct_t;


typedef struct result_struct_{

    // OLD:
    // unsigned int c;

    char concat[255];

} result_struct_t;
